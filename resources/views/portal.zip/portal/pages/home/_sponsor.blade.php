<div class="partner-list">
  <div class="partner-item">
    <a href="#" target="_blank"><img src="{{ asset('portal') }}/assets/img/partner/koniori.jpg" alt="image"></a>
    <a href="#" target="_blank"><img src="{{ asset('portal') }}/assets/img/partner/koniori.jpg" alt="image"></a>
  </div>
  <div class="partner-item">
    <a href="#" target="_blank"><img src="{{ asset('portal') }}/assets/img/partner/menpora.jpg" alt="image"></a>
    <a href="#" target="_blank"><img src="{{ asset('portal') }}/assets/img/partner/menpora.jpg" alt="image"></a>
  </div>
  <div class="partner-item">
    <a href="#" target="_blank"><img src="{{ asset('portal') }}/assets/img/partner/newatu.jpg" alt="image"></a>
    <a href="#" target="_blank"><img src="{{ asset('portal') }}/assets/img/partner/newatu.jpg" alt="image"></a>
  </div>
  <div class="partner-item">
    <a href="#" target="_blank"><img src="{{ asset('portal') }}/assets/img/partner/OG.jpg" alt="image"></a>
    <a href="#" target="_blank"><img src="{{ asset('portal') }}/assets/img/partner/OG.jpg" alt="image"></a>
  </div>
  <div class="partner-item">
    <a href="#" target="_blank"><img src="{{ asset('portal') }}/assets/img/partner/WT2.jpg" alt="image"></a>
    <a href="#" target="_blank"><img src="{{ asset('portal') }}/assets/img/partner/WT2.jpg" alt="image"></a>
  </div>
  <div class="partner-item">
    <a href="#" target="_blank"><img src="{{ asset('portal') }}/assets/img/partner/WT2.jpg" alt="image"></a>
    <a href="#" target="_blank"><img src="{{ asset('portal') }}/assets/img/partner/WT2.jpg" alt="image"></a>
  </div>
</div>
<div class="shape13"><img src="{{ asset('portal') }}/assets/img/shape/13.svg" alt="image"></div>
<div class="shape14"><img src="{{ asset('portal') }}/assets/img/shape/13.svg" alt="image"></div>
