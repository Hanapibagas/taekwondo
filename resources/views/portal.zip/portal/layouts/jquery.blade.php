<!-- jQuery -->
<script src="{{ asset('portal')}}/plugins/jQuery/jquery.min.js"></script>
<!-- Bootstrap JS -->
<script src="{{ asset('portal')}}/plugins/bootstrap/bootstrap.min.js"></script>
<!-- slick slider -->
<script src="{{ asset('portal')}}/plugins/slick/slick.min.js"></script>
<!-- venobox -->
<script src="{{ asset('portal')}}/plugins/Venobox/venobox.min.js"></script>
<!-- aos -->
<script src="{{ asset('portal')}}/plugins/aos/aos.js"></script>
<!-- Main Script -->
<script src="{{ asset('portal')}}/js/script.js"></script>
